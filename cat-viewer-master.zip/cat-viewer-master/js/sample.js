function sampleText(text) {
  return 'bar';
};

module.exports.sampleText = sampleText;
